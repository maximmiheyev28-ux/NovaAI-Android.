const $ = (s) => document.querySelector(s);
const chat = $("#chat"), promptBox = $("#prompt"), sendBtn = $("#sendBtn");
let mode = localStorage.getItem("nova.mode") || "solo";
let history = JSON.parse(localStorage.getItem("nova.history") || "[]");
let settings = JSON.parse(localStorage.getItem("nova.settings") || "{}");
let busy = false;

function saveHistory(){ localStorage.setItem("nova.history", JSON.stringify(history.slice(-100))); }
function setMode(next){
  mode = next; localStorage.setItem("nova.mode", mode);
  document.querySelectorAll(".mode").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));
  $("#welcomeText").textContent = mode==="solo" ? "Самостоятельный режим. История хранится на этом устройстве." : "Совет ИИ. Запрос будет отправлен настроенной модели; для нескольких моделей нужны отдельные подключения.";
  $("#composerNote").textContent = settings.endpoint ? (mode==="solo" ? "Подключённая модель: локальный/настроенный endpoint" : "Онлайн-запрос через настроенный endpoint; несколько моделей пока нужно подключать отдельно") : "Демо без подключённой языковой модели";
}
function addMessage(role, content, label, persist=true){
  $("#welcome")?.remove();
  const wrap=document.createElement("div"); wrap.className="message "+role;
  const lab=document.createElement("div"); lab.className="label"; lab.textContent=label || (role==="user"?"Ты":mode==="council"?"Nova · Совет ИИ":"Nova");
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=content;
  wrap.append(lab,bubble); chat.append(wrap); chat.scrollTop=chat.scrollHeight;
  if(persist){history.push({role,content,label:lab.textContent,mode,at:Date.now()});saveHistory();}
  return wrap;
}
function renderHistory(){
  if(!history.length)return;
  $("#welcome")?.remove();
  history.forEach(m=>addMessage(m.role,m.content,m.label,false));
}
async function callConfiguredModel(userText){
  if(!settings.endpoint || !settings.modelName) return null;
  const headers={"Content-Type":"application/json"};
  if(settings.apiKey) headers.Authorization="Bearer "+settings.apiKey;
  const system = mode==="council"
    ? "Ты — синтезатор ответов в режиме Совет ИИ. Честно обозначай неопределённость, различай факты и предположения. Если доступна только одна модель, не утверждай, что опрошены другие модели."
    : "Ты — Nova AI, локальный персональный помощник. Отвечай прямо, уважительно и по существу. Не выдумывай факты и обозначай неопределённость.";
  const messages=[{role:"system",content:system},...history.slice(-12).filter(m=>m.role==="user"||m.role==="assistant").map(m=>({role:m.role,content:m.content})),{role:"user",content:userText}];
  const response=await fetch(settings.endpoint,{method:"POST",headers,body:JSON.stringify({model:settings.modelName,messages,temperature:0.7})});
  if(!response.ok) throw new Error("Провайдер вернул HTTP "+response.status+". Проверь endpoint, ключ и лимиты.");
  const data=await response.json();
  const result=data.choices?.[0]?.message?.content || data.output_text || data.response;
  if(typeof result!=="string") throw new Error("Ответ API не распознан. Ожидался совместимый формат chat completions.");
  return result;
}
function demoResponse(text){
  if(mode==="council"){
    return "Режим «Совет ИИ» включён, но сейчас не подключены реальные модели. В этой пробной версии нельзя честно сравнить ответы нескольких нейросетей.\n\nЧтобы проверить подключение, открой ⚙ Настройки и укажи совместимый API endpoint, модель и ключ (если он требуется). Для настоящего совета нужны отдельные разрешённые подключения к нескольким провайдерам.";
  }
  return "Это интерфейсный прототип Nova AI. Пока к приложению не подключена языковая модель, я не могу полноценно рассуждать или обучаться — этот ответ не сгенерирован нейросетью.\n\nМожно проверить интерфейс, историю и переключение режимов. Для реального ИИ настрой совместимый API в ⚙ Настройки либо добавь локальный движок и модель. Локальная модель и офлайн-инференс в эту пробную версию ещё не встроены.";
}
async function send(text){
  text=text.trim(); if(!text||busy)return;
  busy=true; sendBtn.disabled=true; promptBox.value=""; promptBox.style.height="auto";
  addMessage("user",text,"Ты");
  const thinking=document.createElement("div"); thinking.className="typing"; thinking.textContent=mode==="council"?"Проверяю доступ к подключённой модели…":"Nova обрабатывает запрос…";chat.append(thinking);chat.scrollTop=chat.scrollHeight;
  try{
    let answer;
    try{answer=await callConfiguredModel(text);}catch(e){answer="Не удалось получить ответ от подключённой модели: "+e.message+"\n\nПроверь настройки и доступность endpoint. Если провайдер запрещает запросы из браузера (CORS), понадобится разрешённый прокси или официальное приложение/SDK.";}
    if(!answer) answer=demoResponse(text);
    thinking.remove(); addMessage("assistant",answer,mode==="council"?"Nova · Совет ИИ":"Nova");
  }finally{thinking.remove();busy=false;sendBtn.disabled=false;promptBox.focus();}
}
document.querySelectorAll(".mode").forEach(b=>b.addEventListener("click",()=>setMode(b.dataset.mode)));
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.textContent)));
$("#composer").addEventListener("submit",e=>{e.preventDefault();send(promptBox.value);});
promptBox.addEventListener("input",()=>{promptBox.style.height="auto";promptBox.style.height=Math.min(promptBox.scrollHeight,140)+"px";});
promptBox.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#composer").requestSubmit();}});
$("#settingsOpen").addEventListener("click",()=>{
  $("#providerName").value=settings.providerName||"";$("#endpoint").value=settings.endpoint||"";$("#apiKey").value=settings.apiKey||"";$("#modelName").value=settings.modelName||"";
  $("#settingsDialog").showModal();
});
$("#settingsClose").addEventListener("click",()=>$("#settingsDialog").close());
$("#settingsForm").addEventListener("submit",e=>{
  e.preventDefault();settings={providerName:$("#providerName").value.trim(),endpoint:$("#endpoint").value.trim(),apiKey:$("#apiKey").value,modelName:$("#modelName").value.trim()};
  localStorage.setItem("nova.settings",JSON.stringify(settings));$("#settingsDialog").close();setMode(mode);
});
$("#forgetKey").addEventListener("click",()=>{settings.apiKey="";localStorage.setItem("nova.settings",JSON.stringify(settings));$("#apiKey").value="";});
$("#clearChat").addEventListener("click",()=>{if(confirm("Очистить историю чата?")){history=[];saveHistory();chat.innerHTML="";chat.append($("#welcomeTemplate")||makeWelcome());}});
function makeWelcome(){const s=document.createElement("section");s.className="welcome";s.innerHTML='<div class="orb"><span>✦</span></div><h1>Чем займёмся?</h1><p id="welcomeText"></p><div class="suggestions"><button class="suggestion">Объясни, как работает нейросеть</button><button class="suggestion">Помоги составить план проекта</button><button class="suggestion">Придумай идею приложения</button></div>';s.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.textContent)));return s;}
$("#wipeAll").addEventListener("click",()=>{if(confirm("Удалить историю, настройки и локальные данные Nova?")){localStorage.removeItem("nova.history");localStorage.removeItem("nova.settings");localStorage.removeItem("nova.mode");history=[];settings={};$("#settingsDialog").close();location.reload();}});
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
setMode(mode);renderHistory();