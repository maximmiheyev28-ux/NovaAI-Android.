# Nova AI Android — prototype 0.1.2

This is a native Android wrapper around the Nova AI web prototype. It includes a GitHub Actions workflow that builds a debug APK and publishes it as a downloadable workflow artifact.

## Put this project into the empty GitHub repository

1. Download and extract this ZIP.
2. Open your repository `maximmiheyev28-ux/NovaAI-Android.` on GitHub.
3. Choose **Add file → Upload files** and upload the *contents* of the `NovaAI_Android` folder (not the enclosing folder), preserving `.github/workflows/build-apk.yml`.
4. Commit the upload to `main`. The workflow should start automatically. If it does not, open **Actions → Build Nova AI APK → Run workflow**.
5. Open the successful workflow run and download `NovaAI-debug-apk` under Artifacts. The archive contains `app-debug.apk`.

## What works in this prototype

- Android app shell and chat UI.
- Local conversation history and settings stored on the device.
- Configurable OpenAI-compatible endpoint/model settings, depending on the provider's CORS and API compatibility.
- Build workflow that attempts to create and upload a debug APK.

## Known limitations

- The “Совет ИИ” mode is a UI/prototype mode; it does not yet orchestrate several independent model providers in parallel.
- No on-device LLM weights or offline inference engine are bundled.
- Online inference requires a provider endpoint and its own API key. Provider terms, billing and rate limits still apply. Do not put high-privilege or sensitive keys into a prototype app: browser storage is not a secure secret vault.
- A successful workflow run is required before treating the APK as built. This environment does not have Android SDK/Gradle available for a local APK build.
